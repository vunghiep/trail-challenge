﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using TaskA.Models;

namespace TaskA.Services
{
    public class EntitySanitizer
    {
        private static readonly string[] DateFormats = { "dd/MM/yyyy", "d/M/yyyy", "MM/dd/yyyy", "M/d/yyyy", "yyyy-MM-dd" };
        private static readonly HashSet<string> TrueValues = new(StringComparer.OrdinalIgnoreCase) { "1", "true", "t", "yes", "y" };

        public List<Entity> ParseEntities(List<string[]> records)
        {
            if (records.Count == 0) return new List<Entity>();

            var idx = records[0]
                .Select((h, i) => (h?.Trim() ?? "", i))
                .Where(x => !string.IsNullOrEmpty(x.Item1))
                .GroupBy(x => x.Item1, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First().i, StringComparer.OrdinalIgnoreCase);

            int GetCol(string name, int fallback) => idx.GetValueOrDefault(name, fallback);
            string? GetVal(string[] row, string name, int fallback) 
                => GetCol(name, fallback) < row.Length ? row[GetCol(name, fallback)] : null;

            return records.Skip(1)
                .Where(row => !(row.Length == 1 && string.IsNullOrWhiteSpace(row[0])))
                .Select(row => new Entity
                {
                    EntityId = SafeInt(GetVal(row, "entity_id", 0)),
                    FirstName = CleanString(GetVal(row, "entity_first_name", 1), 128),
                    MiddleName = CleanString(GetVal(row, "entity_middle_name", 2), 128),
                    LastName = CleanString(GetVal(row, "entity_last_name", 3), 128),
                    DOB = SafeDate(GetVal(row, "entity_dob", 4)),
                    IsMaster = SafeBool(GetVal(row, "is_master", 5)),
                    Address = CleanMultiline(GetVal(row, "address", 6), 512),
                    Gender = CleanString(GetVal(row, "entity_gender", 7), 16)
                })
                .ToList();
        }

        private static string? TrimQuotes(string? value) => value?.Trim().Trim('"');

        private static int SafeInt(string? value) =>
            string.IsNullOrWhiteSpace(value) ? 0 :
            int.TryParse(TrimQuotes(value), out int v) ? v : 0;

        private static string? CleanString(string? value, int max)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = Regex.Replace(TrimQuotes(value)!, @"\s+", " ");
            return value.Length > max ? value[..max] : value;
        }

        private static string? CleanMultiline(string? value, int max)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            var joined = string.Join(Environment.NewLine, 
                TrimQuotes(value)!.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)
                    .Select(l => l.Trim()));
            return joined.Length > max ? joined[..max] : joined;
        }

        private static DateTime? SafeDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = TrimQuotes(value)!;

            return DateTime.TryParseExact(value, DateFormats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var dt) ? dt :
                DateTime.TryParse(value, out dt) ? dt : null;
        }

        private static bool SafeBool(string? value) =>
            string.IsNullOrWhiteSpace(value) ? false :
            TrueValues.Contains(TrimQuotes(value)!);
    }
}
