﻿using System;
using System.Collections.Generic;
using System.IO;
using TaskA.Models;
using OfficeOpenXml;

namespace TaskA.Services
{
    public class ExcelExporter
    {
        public void Export(List<Entity> list)
        {
            string filePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                "Output.xlsx");

            if (File.Exists(filePath)) File.Delete(filePath);

            ExcelPackage.License.SetNonCommercialPersonal("VuNghiep");
            using var package = new ExcelPackage();
            var ws = package.Workbook.Worksheets.Add("Entities");

            // Headers
            string[] headers = { "entity_id", "entity_first_name", "entity_middle_name", 
                "entity_last_name", "entity_dob", "is_master", "address", "entity_gender" };
            for (int i = 0; i < headers.Length; i++)
                ws.Cells[1, i + 1].Value = headers[i];

            // Data rows
            int row = 2;
            foreach (var e in list)
            {
                ws.Cells[row, 1].Value = e.EntityId;
                ws.Cells[row, 2].Value = e.FirstName;
                ws.Cells[row, 3].Value = e.MiddleName;
                ws.Cells[row, 4].Value = e.LastName;
                ws.Cells[row, 5].Value = e.DOB?.ToString("yyyy-MM-dd");
                ws.Cells[row, 6].Value = e.IsMaster ? 1 : 0;
                ws.Cells[row, 7].Value = e.Address;
                ws.Cells[row, 8].Value = e.Gender;
                row++;
            }

            ws.Column(7).Style.WrapText = true;
            ws.Cells[1, 1, row - 1, 8].AutoFitColumns();
            package.SaveAs(filePath);
        }
    }
}
