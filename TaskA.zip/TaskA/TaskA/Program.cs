﻿using System;
using System.IO;
using TaskA.Services;

namespace CsvToXlsxSanitizer
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputPath = Path.Combine("..", "..", "..", "..", "Input.csv");

            var records = new CsvParser().ReadCsv(inputPath);
            var entities = new EntitySanitizer().ParseEntities(records);
            new ExcelExporter().Export(entities);

            Console.WriteLine("Done! Output written to Desktop");
        }
    }
}
