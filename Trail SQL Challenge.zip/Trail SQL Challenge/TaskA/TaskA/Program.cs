﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using TaskA.Services;
namespace CsvToXlsxSanitizer
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string inputPath = "C:\\Users\\Admin\\Desktop\\Trail SQL Challenge\\TaskA\\Input.csv";

            var parser = new CsvParser();
            var sanitizer = new EntitySanitizer();
            var exporter = new ExcelExporter();

            var records = parser.ReadCsv(inputPath);
            var entities = sanitizer.ParseEntities(records);
            exporter.Export(entities);

            Console.WriteLine("Done! Output written to Desktop " );
        }
    }
}
