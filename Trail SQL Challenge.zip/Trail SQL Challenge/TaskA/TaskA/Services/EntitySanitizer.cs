﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TaskA.Models;
namespace TaskA.Services
{
    public class EntitySanitizer
    {
        public List<Entity> ParseEntities(List<string[]> records)
        {
            var list = new List<Entity>();
            if (records.Count == 0) return list;

            var header = records[0];
            var idx = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < header.Length; i++)
                if (!string.IsNullOrEmpty(header[i]) && !idx.ContainsKey(header[i].Trim()))
                    idx[header[i].Trim()] = i;

            int Get(string name, int fallback)
                => idx.ContainsKey(name) ? idx[name] : fallback;

            for (int r = 1; r < records.Count; r++)
            {
                var row = records[r];
                if (row.Length == 1 && string.IsNullOrWhiteSpace(row[0])) continue;

                string At(int pos) => pos < row.Length ? row[pos] : null;

                var entity = new Entity
                {
                    EntityId = SafeInt(At(Get("entity_id", 0))),
                    FirstName = CleanString(At(Get("entity_first_name", 1)), 128),
                    MiddleName = CleanString(At(Get("entity_middle_name", 2)), 128),
                    LastName = CleanString(At(Get("entity_last_name", 3)), 128),
                    DOB = SafeDate(At(Get("entity_dob", 4))),
                    IsMaster = SafeBool(At(Get("is_master", 5))),
                    Address = CleanMultiline(At(Get("address", 6)), 512),
                    Gender = CleanString(At(Get("entity_gender", 7)), 16)
                };

                list.Add(entity);
            }

            return list;
        }

        // ===== Sanitizers =====

        private int SafeInt(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return 0;
            value = value.Trim().Trim('"');
            return int.TryParse(value, out int v) ? v : 0;
        }

        private string CleanString(string value, int max)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = value.Trim().Trim('"');
            value = Regex.Replace(value, @"\s+", " ");
            return value.Length > max ? value.Substring(0, max) : value;
        }

        private string CleanMultiline(string value, int max)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = value.Trim().Trim('"');

            var lines = value.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            for (int i = 0; i < lines.Length; i++)
                lines[i] = lines[i].Trim();

            var joined = string.Join(Environment.NewLine, lines);
            return joined.Length > max ? joined.Substring(0, max) : joined;
        }

        private DateTime? SafeDate(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            value = value.Trim().Trim('"');

            string[] fmts = {
                "dd/MM/yyyy", "d/M/yyyy",
                "MM/dd/yyyy", "M/d/yyyy",
                "yyyy-MM-dd"
            };

            if (DateTime.TryParseExact(value, fmts, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var dt))
                return dt;

            if (DateTime.TryParse(value, out dt))
                return dt;

            return null;
        }

        private bool SafeBool(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            value = value.Trim().Trim('"').ToLower();

            return value switch
            {
                "1" => true,
                "true" => true,
                "t" => true,
                "yes" => true,
                "y" => true,
                _ => false
            };
        }
    }
}
