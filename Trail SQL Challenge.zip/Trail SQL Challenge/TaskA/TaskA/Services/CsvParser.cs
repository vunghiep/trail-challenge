﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskA.Services
{
    public class CsvParser
    {
        public List<string[]> ReadCsv(string path)
        {
            string text = File.ReadAllText(path);
            var records = new List<string[]>();
            var fields = new List<string>();
            var cur = new StringBuilder();

            bool inQuotes = false;
            int i = 0;

            while (i < text.Length)
            {
                char c = text[i];

                if (c == '"')
                {
                    if (inQuotes && i + 1 < text.Length && text[i + 1] == '"')
                    {
                        cur.Append('"');
                        i += 2;
                        continue;
                    }
                    inQuotes = !inQuotes;
                    i++;
                    continue;
                }

                if (!inQuotes)
                {
                    if (c == ',')
                    {
                        fields.Add(cur.ToString());
                        cur.Clear();
                        i++;
                        continue;
                    }

                    if (c == '\r')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '\n') i++;

                        fields.Add(cur.ToString());
                        cur.Clear();
                        records.Add(fields.ToArray());
                        fields = new List<string>();
                        i++;
                        continue;
                    }

                    if (c == '\n')
                    {
                        fields.Add(cur.ToString());
                        cur.Clear();
                        records.Add(fields.ToArray());
                        fields = new List<string>();
                        i++;
                        continue;
                    }
                }

                cur.Append(c);
                i++;
            }

            if (cur.Length > 0 || fields.Count > 0)
            {
                fields.Add(cur.ToString());
                records.Add(fields.ToArray());
            }

            return records;
        }
    }
}
