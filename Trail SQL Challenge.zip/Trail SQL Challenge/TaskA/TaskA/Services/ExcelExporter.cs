﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskA.Models;
using OfficeOpenXml;

namespace TaskA.Services
{
    public class ExcelExporter
    {
        public void Export(List<Entity> list)
        {
            string directory = "C:\\Users\\Admin\\Desktop";
            string fileName = "Output.xlsx";

            // Check if the file already exists and delete it
            string filePath = Path.Combine(directory, fileName);
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
            ExcelPackage.License.SetNonCommercialPersonal("VuNghiep");
            using var package = new ExcelPackage();
            var ws = package.Workbook.Worksheets.Add("Entities");

            ws.Cells[1, 1].Value = "entity_id";
            ws.Cells[1, 2].Value = "entity_first_name";
            ws.Cells[1, 3].Value = "entity_middle_name";
            ws.Cells[1, 4].Value = "entity_last_name";
            ws.Cells[1, 5].Value = "entity_dob";
            ws.Cells[1, 6].Value = "is_master";
            ws.Cells[1, 7].Value = "address";
            ws.Cells[1, 8].Value = "entity_gender";

            int row = 2;
            foreach (var e in list)
            {
                ws.Cells[row, 1].Value = e.EntityId;
                ws.Cells[row, 2].Value = e.FirstName;
                ws.Cells[row, 3].Value = e.MiddleName;
                ws.Cells[row, 4].Value = e.LastName;
                ws.Cells[row, 5].Value = e.DOB?.ToString("yyyy-MM-dd");
                ws.Cells[row, 6].Value = e.IsMaster ? 1 : 0;
                ws.Cells[row, 7].Value = e.Address;
                ws.Cells[row, 8].Value = e.Gender;
                row++;
            }

            ws.Column(7).Style.WrapText = true;

            ws.Cells[1, 1, row - 1, 8].AutoFitColumns();
            package.SaveAs(filePath);
        }
    }
}
