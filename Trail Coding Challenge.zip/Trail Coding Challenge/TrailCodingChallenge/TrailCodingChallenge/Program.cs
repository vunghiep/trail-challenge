﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        int diceQuantity, sides;

        // Để đảm bảo tính logic thì em sẽ check để số xúc xắc nhập vào là số nguyên dương, số mặt xúc xắc nhập vào lớn hơn hoặc bằng 2
        do
        {
            Console.Write("Enter the number of dice (must be a positive integer): ");
        } while (!int.TryParse(Console.ReadLine(), out diceQuantity) || diceQuantity <= 0);

        do
        {
            Console.Write("Enter the number of sides on each die (must be a positive integer greater than or equal to 2): ");
        } while (!int.TryParse(Console.ReadLine(), out sides) || sides < 2);

        int rounds = 1000; 

        Random random = new Random();
        Stopwatch checktime = new Stopwatch();

        checktime.Start();
        for (int round = 1; round <= rounds; round++)
        {
            // Tạo mảng diceRoll để lưu kết quả tung các xúc xắc
            int[] diceRoll = new int[diceQuantity];
            for (int i = 0; i < diceQuantity; i++)
            {
                diceRoll[i] = random.Next(1, sides + 1);
            }

            Array.Sort(diceRoll);
            // Việc sắp xếp mảng trước khi đếm số lần xuất hiện sẽ làm tăng hiệu suất của chương trình

            int maxScore = 0;
            for (int i = 1; i <= sides; i++)
            {
                // Đếm số lần xuất hiện của mỗi mặt xúc xắc
                int count = Array.FindAll(diceRoll, x => x == i).Length;
                // Tính điểm mỗi mặt và tìm ra điểm cao nhất mỗi round
                maxScore = Math.Max(maxScore, i * count);
            }
            //Vì đề bài chỉ cần in ra maxScore của mỗi round nên không cần lưu vào mảng để tối ưu thời gian chạy của chương trình
            Console.WriteLine($"Round {round}: {string.Join(", ", diceRoll)} => {maxScore}");
        }

        checktime.Stop();
        Console.WriteLine($"Time taken: {checktime.ElapsedMilliseconds} ms");
    }
}